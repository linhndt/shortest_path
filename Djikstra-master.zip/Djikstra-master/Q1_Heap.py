from collections import defaultdict
import networkx as nx
import matplotlib.pyplot as plt
# to adjust the read_arcs_list() function (only read from line 3)
# to add more comments
# to adjust the output (display shortest path as an array and a graph (highlight the shortest path))
# to add code to store the graph internally in memory as an array of adjacency list.

def read_arcs_list():  # read a stream of arcs list from .txt file
    """ Convert from arcs list in file txt to python list of arcs."""
    # input format:
    # A,B,5
    # A,C,4
    # B,C,2
    # output format:
    # [['A','B',5]
    # ['A','C',4]
    # ['B','C',2]]

    file = input("File name?")
    with open(file, "r") as f:
        initial_list = [line.split(',') for line in f.read().splitlines()]
        arcs_list = [[x[0], x[1], int(x[2])] for x in initial_list]
    return arcs_list

def choose_root(arcs_list):
    """Ask user to pick a root from all the graph nodes that have non-zero out-degree."""
    root = input("Choose a root node:")
    while root not in arcs_list[:][0]:
        print("The input node is either non-existent or has 0 out-degree. Please try again.")
        root = input("Choose a root node:")
    return root

def adj_dict_from_arcs_list(arcs_list):
    """Convert from python list of arcs to adjacency list (python dict of dicts)"""
    adj_dict = {}
    for row in arcs_list:
        if row[0] not in adj_dict.keys():
            adj_dict[row[0]]={}
        if row[1] not in adj_dict.keys():
            adj_dict[row[1]]={}
        adj_dict[row[0]][row[1]]=row[2]
        adj_dict[row[1]][row[0]]=row[2]
    return adj_dict

def graph_attributes(adj_dict):
    G = nx.DiGraph()
    g3 = nx.from_dict_of_lists(adj_dict, create_using = G)
    G.add_edges_from(g3.edges())
    # getting different graph attributes
    print("---------------------GRAPH ATTRIBUTES---------------------")
    print("Total number of nodes: ", int(G.number_of_nodes()))
    print("Total number of edges: ", int(G.number_of_edges()))
    print("List of all nodes: ", list(G.nodes()))
    print("List of all edges: ", list(G.edges()))
    print("In-degree for all nodes: ", dict(G.in_degree))
    print("Out degree for all nodes: ", dict(G.out_degree))
    return G
def __siftdown(heap, startpos, pos):
    newitem = heap[pos]
    while pos > startpos:
        parentpos = (pos - 1) >> 1
        parent = heap[parentpos]
        if newitem < parent:
            heap[pos] = parent
            pos = parentpos
            continue
        break
    heap[pos] = newitem

def __siftup(heap, pos):
    endpos = len(heap)
    startpos = pos
    newitem = heap[pos]
    childpos = 2 * pos + 1
    while childpos < endpos:
        rightpos = childpos + 1
        if rightpos < endpos and not heap[childpos] < heap[rightpos]:
            childpos = rightpos
        heap[pos] = heap[childpos]
        pos = childpos
        childpos = 2 * pos + 1
    heap[pos] = newitem
    __siftdown(heap, startpos, pos)

def heappush(heap, item):
    """Push item onto heap, maintaining the heap invariant."""
    heap.append(item)
    __siftdown(heap, 0, len(heap) - 1)

def heappop(heap):
    """Pop the smallest item off the heap, maintaining the heap invariant."""
    lastelt = heap.pop()
    if heap:
        returnitem = heap[0]
        heap[0] = lastelt
        __siftup(heap, 0)
        return returnitem
    return lastelt

def heapify(x):
    """Transform list into a heap, in-place, in 0(len(x)) time."""
    n = len(x)
    for i in reversed(range(n//2)):
        __siftup(x, i)

def heap_shortest_path_spanning_tree(adj_dict, root):
    hspst = defaultdict(set) # Initially, create shortest path spanning tree as an empty dict
    visited = set([root]) # Create set of nodes visited with root r
    arcs = [(weight, root, neighbour) for neighbour, weight in adj_dict[root].items()] # Create list neighbours of r
    heapify(arcs) #shift down neighbours of r as children of r in the heap

    while arcs:
        weight, nodes, neighbour = heappop(arcs) # remove and return the smallest element from heap
        if neighbour not in visited: #add neighbours to priority queue
            visited.add(neighbour) #add visited neighbours to the visited set
            hspst[nodes].add(neighbour)
            for neighbour_of_neighbour, weight in adj_dict[neighbour].items():
                if neighbour_of_neighbour not in visited: #add neighbours of neighbours to priority queue
                    heappush(arcs, (weight, neighbour, neighbour_of_neighbour))
    print("-------------------------SOLUTION-------------------------")
    print(dict(hspst))

def graph(G):
    plt.figure(figsize=(9, 9))
    nx.draw_networkx(G, with_label=True, node_color='green')
    plt.show()

def display_heap():
    arcs_list = read_arcs_list()
    root = choose_root(arcs_list)
    adj_dict = adj_dict_from_arcs_list(arcs_list)
    G = graph_attributes(adj_dict)
    heap_shortest_path_spanning_tree(adj_dict, root)
    graph(G)

display_heap()

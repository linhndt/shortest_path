import matplotlib.pyplot as plt
import networkx as nx
import numpy as np

#Define user input function
#file = input('Enter the name of a file you want to read:')
#with open(file, "r") as f:
    #list = [line.split(',') for line in f.read().splitlines()]
    #arc_list = [[x[0], x[1], int(x[2])] for x in list]
#adj_list = arc_list

A = [[0, 1, 1, 0, 0, 0, 0],
     [1, 0, 1, 0, 0, 0, 0],
     [1, 1, 0, 1, 0, 0, 0],
     [0, 0, 1, 0, 1, 0, 0],
     [0, 0, 0, 1, 0, 1, 1],
     [0, 0, 0, 0, 1, 0, 1],
     [0, 0, 0, 0, 1, 1, 0]]

G = nx.from_numpy_matrix(np.array(A))
nx.draw(G, with_labels=True)

close_centrality = nx.closeness_centrality(G, u=None, distance=None, wf_improved=True)
print("Closeness Centrality: " + str(close_centrality))

bet_centrality = nx.betweenness_centrality(G, k=None, normalized = True, weight=None, endpoints = False, seed=None)
print("Betweenenness Centrality: " + str(bet_centrality))

deg_centrality = nx.degree_centrality(G)
print("Degree Centrality: " + str(deg_centrality))

eigen_centrality = nx.eigenvector_centrality(G, max_iter=100, tol=1e-06, nstart=None, weight=None)
print("Eigenvector Centrality: " + str(eigen_centrality))
#G.add_weighted_edges_from(adj_list)
#print("Shortest length is " + str(nx.single_source_dijkstra(G, root, '10')))

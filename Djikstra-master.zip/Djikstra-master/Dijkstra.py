import networkx as nx

#Define user input function
file = input('Enter the name of a file you want to read:')
with open(file, "r") as f:
    list = [line.split(',') for line in f.read().splitlines()]
    arc_list = [[x[0], x[1], int(x[2])] for x in list]
adj_list = arc_list

root = input("Choose a root node:")
while root not in arc_list[:][0]:
    print("The input node is either non-existent or has 0 out-degree. Please try again.")
    root = input("Choose a root node:")

G = nx.Graph()
G.add_weighted_edges_from(adj_list)
print("Shortest length is " + str(nx.single_source_dijkstra(G, root, '10')))
